SwitchDoc Labs, LLC
June 2014

blescanner is a python program designed to read iBeacon advertizments using a Bluetooth Dongle on a Raspberry Pi

To test, "sudo python testblescanner.py"


